package com.sudoagile.screenmatch.calculos;

public interface Clasificable {
    int getClasificacion();
}
